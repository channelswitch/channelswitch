#!/bin/sh
# In $1.csv:
# Type, Inputs, Period, MHz, LUT_ff_pairs, Synth_Time, RAM_Bits

RESULTS_CSV="$1"
FIELDS="Type Inputs Period MHz LUT_ff_pairs Synth_Time RAM_Bits"

# $1 - name of field
get_field_number() {
	j=1
	for i in $FIELDS; do
		if [ "$i" = "$1" ]; then
			printf "%d" $j
		fi
		j=$(expr $j + 1)
	done
}

# $1 - the output file
# $2 - fields (will be sorted by the first field)
# $3 - filter variable
# $4 - its value
process_results() {
	exec 3>$1
	LAST=""
	for i in $2; do
		if [ -n "$LAST" ]; then
			printf "$LAST, "
		fi
		LAST="$i"
	done >&3
	printf "$LAST\n" >&3
	cat $RESULTS_CSV | while read line; do
		j=1
		for i in $FIELDS; do
			eval "$i=$(echo $line | cut -d, -f$j | xargs)"
			j=$(expr $j + 1)
		done
#		if [ "$(eval "printf "%s" \$$3")" -eq "$4" ]; then
		if eval "$3"; then
			LAST=""
			for i in $2; do
				if [ -n "$LAST" ]; then
					printf "%s, " "$LAST"
				fi
				LAST=$(echo $line | cut -d, -f$(get_field_number $i) | xargs)
			done
			printf "%s\n" "$LAST"
		fi
	done  | sort -n >&3
	exec 3>&-
}

echo 0/12
process_results InputsMHz.csv "Inputs MHz Type" '[ $Period -eq 512 ]'
echo 1/12
process_results PeriodMHz.csv "Period MHz Type" '[ $Inputs -eq 8 ]'
echo 2/12
process_results InputsPairs.csv "Inputs LUT_ff_pairs Type" '[ $Period -eq 512 ]'
echo 3/12
process_results PeriodPairs.csv "Period LUT_ff_pairs Type" '[ $Inputs -eq 8 ]'
echo 4/12
process_results InputsBits.csv "Inputs RAM_Bits Type" '[ $Period -eq 512 ]'
echo 5/12
process_results PeriodBits.csv "Period RAM_Bits Type" '[ $Inputs -eq 8 ]'
echo 6/12
process_results EqualMHz.csv "Inputs Period MHz Type" '[ $(expr $Inputs \* $Period) -eq 4096 ]'
echo 7/12
process_results EqualPairs.csv "Inputs Period LUT_ff_pairs Type" '[ $(expr $Inputs \* $Period) -eq 4096 ]'
echo 8/12
process_results EqualBits.csv "Inputs Period RAM_Bits Type" '[ $(expr $Inputs \* $Period) -eq 4096 ]'
echo 9/12
process_results PeriodMHz4.csv "Period MHz Type" '[ $Inputs -eq 4 ]'
echo 10/12
process_results PeriodPairs4.csv "Period LUT_ff_pairs Type" '[ $Inputs -eq 4 ]'
echo 11/12
process_results PeriodBits4.csv "Period RAM_Bits Type" '[ $Inputs -eq 4 ]'
echo 12/12
touch all_csv_files
